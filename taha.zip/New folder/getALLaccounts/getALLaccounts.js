import { LightningElement , wire} from 'lwc';
import getAccountList from '@salesforce/apex/AccountController.getAccountList';

export default class GetALLaccounts extends LightningElement {
        @wire(getAccountList) wiredAccounts;
   
}